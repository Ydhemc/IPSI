#include "joueur_alphabeta.hh"


Joueur_AlphaBeta::Joueur_AlphaBeta(std::string nom, bool joueur)
    :Joueur(nom,joueur)
{}



void Joueur_AlphaBeta::recherche_coup(Jeu j, couple &coup)
{

}
